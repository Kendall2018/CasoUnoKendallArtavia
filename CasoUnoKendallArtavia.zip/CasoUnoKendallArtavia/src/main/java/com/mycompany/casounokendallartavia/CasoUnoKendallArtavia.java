/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.casounokendallartavia;

/**
 *
 * @author admin
 */
public class CasoUnoKendallArtavia {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
