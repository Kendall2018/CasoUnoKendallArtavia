package com.mycompany.casounokendallartavia.Repository;

import com.mycompany.casounokendallartavia.Domain.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {
}